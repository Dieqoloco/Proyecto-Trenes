#Configuraciones
titulo_ventana = "Simulador"