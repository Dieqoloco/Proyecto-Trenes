from .configuraciones import titulo_ventana
from .colores import color_bg_principal

__all__ = [
    "titulo_ventana",
    "color_bg_principal"
]